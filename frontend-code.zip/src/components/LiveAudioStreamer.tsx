"use client";

export interface StreamMetrics {
  noiseFloor: number;
  silenceThreshold: number;
  speechThreshold: number;
  isCalibrating: boolean;
  currentRms: number;
  silenceCountdown: number;
  lastCalibration: Date;
}

export default class LiveAudioStreamer {
  private ws: WebSocket | null = null;
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private isStreaming = false;
  private isMuted = false;

  private sessionId: string;
  private config: any;
  private onTranscriptUpdate: (txt: string, ready: boolean) => void;
  private onMetricsUpdate: (m: StreamMetrics) => void;
  private onConnectionOpen: () => void;
  private onConnectionError: (error: string) => void;
  private audioDeviceId?: string;
  private wsUrl: string;

  constructor(
    sessionId: string,
    config: any,
    onTranscriptUpdate: (txt: string, ready: boolean) => void,
    onMetricsUpdate: (m: StreamMetrics) => void,
    onConnectionOpen: () => void,
    onConnectionError: (error: string) => void,
    wsUrl: string,
    audioDeviceId?: string
  ) {
    this.sessionId = sessionId;
    this.config = config;
    this.onTranscriptUpdate = onTranscriptUpdate;
    this.onMetricsUpdate = onMetricsUpdate;
    this.onConnectionOpen = onConnectionOpen;
    this.onConnectionError = onConnectionError;
    this.wsUrl = wsUrl;
    this.audioDeviceId = audioDeviceId;
  }

  async startStreaming() {
    if (this.isStreaming) {
      console.log("[LiveAudioStreamer] Already streaming.");
      return;
    }
    this.isStreaming = true;
    console.log("[LiveAudioStreamer] Attempting to start streaming...");

    try {
      const fullWsUrl = `${this.wsUrl}${this.sessionId}`;
      this.ws = new WebSocket(fullWsUrl);
    } catch (error) {
      console.error("[LiveAudioStreamer] Failed to create WebSocket.", error);
      this.onConnectionError("Failed to initialize connection.");
      this.cleanup();
      return;
    }

    this.ws.binaryType = "arraybuffer";

    this.ws.onopen = async () => {
      console.log("[LiveAudioStreamer] WebSocket connection opened successfully.");
      this.onConnectionOpen();

      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: "config", payload: this.config }));
      }

      try {
        const audioConstraint = this.audioDeviceId ? { deviceId: { exact: this.audioDeviceId } } : true;
        this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraint });
      } catch (err) {
        console.error("[LiveAudioStreamer] ERROR: Could not get microphone access.", err);
        this.onConnectionError("Microphone access denied.");
        this.cleanup();
        return;
      }

      this.audioContext = new AudioContext({ sampleRate: this.config.sample_rate });
      try {
        await this.audioContext.audioWorklet.addModule("/recorder-worklet.js");
      } catch (err) {
        console.error("[LiveAudioStreamer] ERROR: Failed to load audio worklet.", err);
        this.onConnectionError("Audio processor failed.");
        this.cleanup();
        return;
      }

      if (this.audioContext && this.mediaStream) {
        this.workletNode = new AudioWorkletNode(this.audioContext, "recorder-processor");
        this.workletNode.port.onmessage = (ev: MessageEvent) => {
          const msg = ev.data;
          if (msg.type === "metrics") {
            this.onMetricsUpdate(msg);
          } else if (msg instanceof Float32Array && this.ws?.readyState === WebSocket.OPEN && !this.isMuted) {
            const pcm = msg;
            const int16 = Int16Array.from(pcm, v => {
              const s = Math.max(-1, Math.min(1, v));
              return s < 0 ? s * 0x8000 : s * 0x7fff;
            });
            this.ws.send(int16.buffer);
          }
        };
        const source = this.audioContext.createMediaStreamSource(this.mediaStream);
        source.connect(this.workletNode).connect(this.audioContext.destination);
      }
    };

    this.ws.onmessage = (ev) => {
      let t: string;
      try {
        const data = JSON.parse(ev.data as string);
        t = data.transcript ?? JSON.stringify(data);
      } catch {
        t = (ev.data as string).trim();
      }
      this.onTranscriptUpdate(t, data.is_final ?? false);
    };

    this.ws.onclose = (event) => {
      if (!event.wasClean) {
        this.onConnectionError("Connection closed unexpectedly.");
      }
      this.cleanup();
    };

    this.ws.onerror = (err) => {
      console.error("[LiveAudioStreamer] WebSocket error.", err);
      this.onConnectionError("WebSocket connection failed.");
      this.cleanup();
    };
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  stopStreaming() {
    this.cleanup();
  }

  private cleanup() {
    this.workletNode?.port.close();
    this.workletNode?.disconnect();
    if (this.audioContext && this.audioContext.state !== "closed") {
      this.audioContext.close().catch(console.error);
    }
    this.mediaStream?.getTracks().forEach((t) => t.stop());
    
    if (this.ws) {
      this.ws.onopen = null;
      this.ws.onmessage = null;
      this.ws.onclose = null;
      this.ws.onerror = null;
      if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
        this.ws.close();
      }
    }
    this.ws = null;
    this.isStreaming = false;
  }
}