import { useState } from "react";
import { WelcomePage } from "./WelcomePage";
import { SystemCheckPage } from "./SystemCheckPage";
import { AssessmentInterface } from "./AssessmentInterface";
import { ResultsPage } from "./ResultsPage";

type AssessmentStep = 'welcome' | 'system-check' | 'assessment' | 'results';

export const AssessmentFlow = () => {
  const [currentStep, setCurrentStep] = useState<AssessmentStep>('welcome');

  const handleGetStarted = () => {
    setCurrentStep('system-check');
  };

  const handleStartAssessment = () => {
    setCurrentStep('assessment');
  };

  const handleCompleteAssessment = () => {
    setCurrentStep('results');
  };

  switch (currentStep) {
    case 'welcome':
      return <WelcomePage onGetStarted={handleGetStarted} />;
    
    case 'system-check':
      return <SystemCheckPage onStartAssessment={handleStartAssessment} />;
    
    case 'assessment':
      return <AssessmentInterface onComplete={handleCompleteAssessment} />;
    
    case 'results':
      return <ResultsPage />;
    
    default:
      return <WelcomePage onGetStarted={handleGetStarted} />;
  }
};