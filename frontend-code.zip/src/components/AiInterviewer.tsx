import { cn } from '@/lib/utils';
import aiAvatar from '@/assets/ai-avatar.png';

interface AiInterviewerProps {
  isListening: boolean;
  isSpeaking: boolean;
}

export const AiInterviewer = ({ isListening, isSpeaking }: AiInterviewerProps) => {
  return (
    <div className="flex justify-center w-full p-4">
      <div className={cn(
        "w-36 h-36 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center relative overflow-hidden border-4 border-slate-200 dark:border-slate-700 shadow-lg transition-all duration-300",
        isListening && "ai-listening-pulse",
        isSpeaking && "ai-speaking-pulse"
      )}>
        {/* The image is now used as the content of the circle */}
        <img src={aiAvatar} alt="AI Interviewer" className="w-full h-full object-cover" />
      </div>
    </div>
  );
};
