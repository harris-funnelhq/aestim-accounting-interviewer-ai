import { HistoryItem } from "@/pages/Interview";
import { useRef } from "react";
import { gsap } from "gsap";
import { useGSAP } from "@gsap/react";

interface ConversationPanelProps {
  history: HistoryItem[];
  isWaitingForResponse: boolean;
}

const ConversationPanel = ({ history, isWaitingForResponse }: ConversationPanelProps) => {
  const lastAiMessage = history.filter(item => item.role === 'model').pop();
  const bubbleRef = useRef(null);
  const textRef = useRef<HTMLParagraphElement>(null);

  useGSAP(() => {
    if (lastAiMessage && textRef.current) {
      const fullText = lastAiMessage.parts[0].text;
      
      // The conditional check that prevented the first message from animating has been removed.
      // Now, all messages, including the first one, will animate.

      // Split text into words and wrap each in a span
      const words = fullText.split(' ');
      textRef.current.innerHTML = ''; // Clear previous text
      words.forEach(word => {
        const span = document.createElement('span');
        span.textContent = word + ' ';
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        span.style.transform = 'translateY(10px)';
        textRef.current.appendChild(span);
      });

      // Animate the words in one by one
      gsap.to(textRef.current.children, {
        opacity: 1,
        y: 0,
        stagger: 0.08, // Time between each word appearing
        ease: 'power3.out',
        delay: 0.2, // Brief "thinking" delay before animation starts
      });
    }
  }, { scope: bubbleRef, dependencies: [lastAiMessage] });

  return (
    <div className="flex flex-col h-full items-center pt-8">
      {/* The AiInterviewer component has been removed from here */}
      
      <div className="flex-1 flex items-start justify-center p-6 w-full mt-4">
        {isWaitingForResponse ? (
          // "Thinking" indicator
          <div className="relative max-w-2xl w-full">
            <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-lg min-h-[120px] flex items-center justify-center">
              <div className="flex items-center justify-center space-x-2">
                <div className="h-2.5 w-2.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="h-2.5 w-2.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="h-2.5 w-2.5 bg-slate-400 rounded-full animate-bounce"></div>
              </div>
            </div>
            <div className="absolute left-1/2 -translate-x-1/2 -top-3 w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-b-[15px] border-b-white dark:border-b-slate-800"></div>
          </div>
        ) : lastAiMessage && (
          // The main speech bubble with GSAP animation
          <div 
            key={lastAiMessage.parts[0].text} // This key forces the component to re-mount and re-animate
            ref={bubbleRef} 
            className="relative max-w-2xl w-full"
          >
            <div className="bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-2xl p-6 text-center text-xl shadow-lg min-h-[120px]">
              <p ref={textRef} className="whitespace-pre-wrap"></p>
            </div>
            {/* The tail of the bubble pointing up to the AI avatar */}
            <div className="absolute left-1/2 -translate-x-1/2 -top-3 w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-b-[15px] border-b-white dark:border-b-slate-800"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ConversationPanel;
