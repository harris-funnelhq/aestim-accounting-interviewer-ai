import React from 'react';
import { Button } from './ui/button';
import { ArrowLeft } from 'lucide-react';
import SpreadsheetTask from './SpreadsheetTask';

interface InteractiveQuestionPanelProps {
  onPreviousClick: () => void;
}

export const InteractiveQuestionPanel = ({ onPreviousClick }: InteractiveQuestionPanelProps) => {
  // Example data and description that you would receive from your assessment logic
  const taskDescription = "In the sheet below, please write a formula in cell B5 to calculate the total sales for the 'North' region.";
  const taskData = [
    { region: 'North', sales: 15000 },
    { region: 'South', sales: 12000 },
    { region: 'North', sales: 18000 },
    { region: 'East', sales: 22000 },
  ];

  return (
    <div className="relative w-full bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-6 sm:p-8 flex flex-col justify-center min-h-[400px]">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Interactive Task</h2>
        {/* The ToggleGroup has been removed */}
      </div>
      
      <div className="flex-grow my-4">
        {/* 
          Here you would add logic to display the correct task component.
          For now, we directly render the SpreadsheetTask with the example data.
        */}
        <SpreadsheetTask 
          description={taskDescription}
          data={taskData}
        />
      </div>
    </div>
  );
};