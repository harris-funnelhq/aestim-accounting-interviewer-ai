import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Star, TrendingUp } from "lucide-react";

interface ResultsPageProps {
  candidateName?: string;
  companyName?: string;
}

// Mock competency data - in real app this would come from assessment results
const competencyData = [
  { name: 'Technical Skills', score: 85, color: 'hsl(217, 91%, 60%)' },
  { name: 'Communication', score: 92, color: 'hsl(142, 69%, 58%)' },
  { name: 'Problem Solving', score: 78, color: 'hsl(38, 92%, 50%)' },
  { name: 'Attention to Detail', score: 88, color: 'hsl(213, 94%, 68%)' },
  { name: 'Time Management', score: 82, color: 'hsl(270, 95%, 75%)' },
  { name: 'Adaptability', score: 75, color: 'hsl(340, 82%, 52%)' },
  { name: 'Industry Knowledge', score: 90, color: 'hsl(171, 77%, 64%)' },
  { name: 'Critical Thinking', score: 86, color: 'hsl(47, 96%, 53%)' }
];

export const ResultsPage = ({
  candidateName = "Alex",
  companyName = "TechCorp Solutions"
}: ResultsPageProps) => {
  // Calculate octagon points for radar chart
  const centerX = 150;
  const centerY = 150;
  const maxRadius = 120;
  
  const getPointOnOctagon = (index: number, score: number) => {
    const angle = (index * 45 - 90) * (Math.PI / 180); // Start from top, 45° increments
    const radius = (score / 100) * maxRadius;
    const x = centerX + Math.cos(angle) * radius;
    const y = centerY + Math.sin(angle) * radius;
    return { x, y };
  };

  const getOctagonVertex = (index: number) => {
    const angle = (index * 45 - 90) * (Math.PI / 180);
    const x = centerX + Math.cos(angle) * maxRadius;
    const y = centerY + Math.sin(angle) * maxRadius;
    return { x, y };
  };

  // Create paths for the radar chart
  const dataPoints = competencyData.map((comp, index) => getPointOnOctagon(index, comp.score));
  const dataPath = `M${dataPoints.map(p => `${p.x},${p.y}`).join(' L')} Z`;
  
  const octagonVertices = Array.from({ length: 8 }, (_, i) => getOctagonVertex(i));
  const octagonPath = `M${octagonVertices.map(p => `${p.x},${p.y}`).join(' L')} Z`;

  // Grid lines (25%, 50%, 75%, 100%)
  const gridPaths = [25, 50, 75, 100].map(percentage => {
    const points = Array.from({ length: 8 }, (_, i) => getPointOnOctagon(i, percentage));
    return `M${points.map(p => `${p.x},${p.y}`).join(' L')} Z`;
  });

  const averageScore = Math.round(competencyData.reduce((sum, comp) => sum + comp.score, 0) / competencyData.length);

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="px-6 py-4 flex justify-between items-center bg-background/80 backdrop-blur-sm border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">TC</span>
          </div>
          <span className="text-lg font-semibold text-foreground">{companyName}</span>
        </div>
        <div className="text-sm text-muted-foreground">
          Powered by <span className="font-semibold text-primary">Aestim</span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        {/* Completion Message */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-success" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-3">
            Assessment Complete!
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Thank you, {candidateName}. Your assessment has been successfully submitted and the detailed report has been sent to {companyName}.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Radar Chart */}
          <Card className="p-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-semibold text-foreground mb-2">
                Your Personal Competency Profile
              </h2>
              <div className="flex items-center justify-center gap-2 mb-4">
                <Star className="w-5 h-5 text-warning fill-current" />
                <span className="text-lg font-semibold text-foreground">
                  Overall Score: {averageScore}%
                </span>
              </div>
            </div>

            <div className="flex justify-center mb-6">
              <svg width="300" height="300" viewBox="0 0 300 300" className="drop-shadow-sm">
                {/* Grid lines */}
                {gridPaths.map((path, index) => (
                  <path
                    key={index}
                    d={path}
                    fill="none"
                    stroke="hsl(var(--border))"
                    strokeWidth="1"
                    opacity={0.3}
                  />
                ))}
                
                {/* Axis lines */}
                {octagonVertices.map((vertex, index) => (
                  <line
                    key={index}
                    x1={centerX}
                    y1={centerY}
                    x2={vertex.x}
                    y2={vertex.y}
                    stroke="hsl(var(--border))"
                    strokeWidth="1"
                    opacity={0.3}
                  />
                ))}

                {/* Data area */}
                <path
                  d={dataPath}
                  fill="hsl(var(--primary))"
                  fillOpacity="0.15"
                  stroke="hsl(var(--primary))"
                  strokeWidth="2"
                />

                {/* Data points */}
                {dataPoints.map((point, index) => (
                  <circle
                    key={index}
                    cx={point.x}
                    cy={point.y}
                    r="4"
                    fill={competencyData[index].color}
                    stroke="white"
                    strokeWidth="2"
                  />
                ))}

                {/* Labels */}
                {competencyData.map((comp, index) => {
                  const labelVertex = getOctagonVertex(index);
                  const angle = (index * 45 - 90) * (Math.PI / 180);
                  const labelX = centerX + Math.cos(angle) * (maxRadius + 35);
                  const labelY = centerY + Math.sin(angle) * (maxRadius + 35);
                  
                  return (
                    <text
                      key={index}
                      x={labelX}
                      y={labelY}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      className="text-xs font-medium fill-current text-foreground"
                    >
                      {comp.name}
                    </text>
                  );
                })}
              </svg>
            </div>

            <div className="text-center text-sm text-muted-foreground">
              <p>This chart shows your relative strengths across key competencies.</p>
              <p>The larger the area, the stronger your overall profile.</p>
            </div>
          </Card>

          {/* Competency Breakdown */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Competency Breakdown
              </h3>
              <div className="space-y-4">
                {competencyData.map((comp, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-foreground">{comp.name}</span>
                      <Badge 
                        variant="outline" 
                        className="bg-background"
                        style={{ borderColor: comp.color, color: comp.color }}
                      >
                        {comp.score}%
                      </Badge>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{
                          width: `${comp.score}%`,
                          backgroundColor: comp.color
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-4">Next Steps</h3>
              <div className="space-y-3 text-muted-foreground">
                <p>
                  The hiring team at <span className="font-semibold text-foreground">{companyName}</span> will 
                  review your full report and will be in touch with you regarding the next steps in the hiring process.
                </p>
                <p>
                  <span className="font-semibold text-foreground">We wish you the best of luck!</span>
                </p>
              </div>
              
              <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-accent/5 rounded-lg">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4 text-primary" />
                  </div>
                  <div className="text-sm">
                    <div className="font-medium text-foreground mb-1">Assessment Summary</div>
                    <div className="text-muted-foreground">
                      Your responses have been analyzed across 8 core competencies. 
                      The results provide insights into your professional strengths and potential areas for growth.
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};