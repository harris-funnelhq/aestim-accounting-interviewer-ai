import React from 'react';
import { Input } from "@/components/ui/input";

// Define the props the component will accept
interface SpreadsheetTaskProps {
  description: string;
  data: { region: string; sales: number }[];
}

const SpreadsheetTask = ({ description, data }: SpreadsheetTaskProps) => {
  return (
    <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg border border-slate-200 dark:border-slate-700">
      <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
        {/* The description is now passed in as a prop */}
        <strong>Task:</strong> {description}
      </p>
      <div className="grid grid-cols-[40px_1fr_1fr] gap-px bg-slate-300 dark:bg-slate-600 border border-slate-300 dark:border-slate-600 text-sm">
        {/* Headers */}
        <div className="bg-slate-100 dark:bg-slate-700 p-2 text-center font-semibold"></div>
        <div className="bg-slate-100 dark:bg-slate-700 p-2 text-center font-semibold">A</div>
        <div className="bg-slate-100 dark:bg-slate-700 p-2 text-center font-semibold">B</div>
        {/* Data Rows are now rendered from the data prop */}
        {data.map((row, rowIndex) => (
          <div style={{ display: 'contents' }} key={rowIndex}>
            <div className="bg-slate-100 dark:bg-slate-700 p-2 text-center font-semibold">{rowIndex + 1}</div>
            <div className="bg-white dark:bg-slate-800 p-2">{row.region}</div>
            <div className="bg-white dark:bg-slate-800 p-2 text-right">{row.sales.toLocaleString()}</div>
          </div>
        ))}
        {/* Formula Row */}
        <div className="bg-slate-100 dark:bg-slate-700 p-2 text-center font-semibold">{data.length + 1}</div>
        <div className="bg-white dark:bg-slate-800 p-2 font-semibold">Total North:</div>
        <div className="bg-white dark:bg-slate-800 p-0 flex items-center justify-center ring-2 ring-sky-500 ring-offset-1 ring-offset-slate-800">
          <Input
            placeholder="=SUMIF(...)"
            className="w-full h-full border-0 rounded-none bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
          />
        </div>
      </div>
    </div>
  );
};

export default SpreadsheetTask;