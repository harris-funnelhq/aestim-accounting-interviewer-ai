import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import ConversationPanel from '@/components/ConversationPanel';
import { AudioControls } from '@/components/AudioControls';
import LiveAudioStreamer from '@/components/LiveAudioStreamer';
import CartesiaSpeaker, { CartesiaSpeakerHandle } from '@/components/CartesiaSpeaker';
import { AiInterviewer } from '@/components/AiInterviewer';
import { InteractiveQuestionPanel } from '@/components/InteractiveQuestionPanel';

// --- Configuration ---
const BACKEND_URL = import.meta.env.VITE_LLM_BACKEND_URL;
const WEBSOCKET_URL = import.meta.env.VITE_STT_WEBSOCKET_URL;

export interface HistoryItem {
  role: 'user' | 'model';
  parts: { text: string }[];
}

const DUMMY_WELCOME_MESSAGE: HistoryItem = {
  role: 'model',
  parts: [{ text: "Welcome to the Aestim AI Accounting Assessment. I will be your interviewer today. When you're ready, we can begin." }]
};

const Interview = () => {
  // --- State and Refs ---
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [audioLevel, setAudioLevel] = useState(0);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedAudioDevice, setSelectedAudioDevice] = useState('');
  const [history, setHistory] = useState<HistoryItem[]>([DUMMY_WELCOME_MESSAGE]);
  const [currentUtterance, setCurrentUtterance] = useState("");
  const [messageQueue, setMessageQueue] = useState("");
  const [isWaitingForResponse, setIsWaitingForResponse] = useState(false);
  const [textToSpeak, setTextToSpeak] = useState(DUMMY_WELCOME_MESSAGE.parts[0].text);
  const [isInteractiveQuestion, setIsInteractiveQuestion] = useState(false);
  
  const streamerRef = useRef<LiveAudioStreamer | null>(null);
  const speakerRef = useRef<CartesiaSpeakerHandle>(null);
  const activityTimerRef = useRef<NodeJS.Timeout | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const isSpeakingRef = useRef(isSpeaking);
  const currentUtteranceRef = useRef(currentUtterance);
  const messageQueueRef = useRef(messageQueue);
  const isWaitingRef = useRef(isWaitingForResponse);
  const historyRef = useRef(history);
  const avatarRef = useRef(null);
  const isFirstRun = useRef(true); // To prevent initial animation

  // --- GSAP Animation Hook ---
  useGSAP(() => {
    // On the very first run, just set the initial position instantly without animation.
    if (isFirstRun.current) {
      gsap.set(avatarRef.current, {
        left: '50%',
        xPercent: -50,
        y: 0, // Set initial vertical position
      });
      isFirstRun.current = false;
      return;
    }

    // On subsequent changes, create a timeline for a curved path.
    const tl = gsap.timeline();
    if (isInteractiveQuestion) {
      // Animate right and down with an overlap to create the curve.
      tl.to(avatarRef.current, {
        left: '100%',
        xPercent: -150,
        duration: 1.2,
        ease: 'power2.inOut',
      })
      .to(avatarRef.current, {
        y: 160, // Move down by 50px
        duration: 1.3,
        ease: 'power2.inOut',
      }, "-=1.0"); // Overlap the start of this animation by 1s for a smooth curve
    } else {
      // Animate back to the original position along the same curved path.
      tl.to(avatarRef.current, {
        left: '50%',
        xPercent: -50,
        duration: 1.2,
        ease: 'power2.inOut',
      })
      .to(avatarRef.current, {
        y: 0,
        duration: 1.0,
        ease: 'power2.inOut',
      }, "-=1.0");
    }
  }, { dependencies: [isInteractiveQuestion] });

  // --- Logic ---
  useEffect(() => { isSpeakingRef.current = isSpeaking; }, [isSpeaking]);
  useEffect(() => { currentUtteranceRef.current = currentUtterance; }, [currentUtterance]);
  useEffect(() => { messageQueueRef.current = messageQueue; }, [messageQueue]);
  useEffect(() => { isWaitingRef.current = isWaitingForResponse; }, [isWaitingForResponse]);
  useEffect(() => { historyRef.current = history; }, [history]);

  useEffect(() => {
    const getAudioDevices = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        const allDevices = await navigator.mediaDevices.enumerateDevices();
        const micDevices = allDevices.filter(device => device.kind === 'audioinput');
        setAudioDevices(micDevices);
        if (micDevices.length > 0) setSelectedAudioDevice(micDevices[0].deviceId);
      } catch (err) { console.error("Error accessing media devices:", err); }
    };
    getAudioDevices();
  }, []);

  const sendChatMessage = async (payload: { message: string }) => {
    if (abortControllerRef.current) abortControllerRef.current.abort();
    abortControllerRef.current = new AbortController();
    const historyForAPI = [...historyRef.current];
    const newUserMessage: HistoryItem = { role: 'user', parts: [{ text: payload.message }] };
    setHistory(prev => [...prev, newUserMessage]);
    setIsWaitingForResponse(true);
    try {
      const response = await fetch(BACKEND_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ history: [...historyForAPI, newUserMessage] }),
        signal: abortControllerRef.current.signal,
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      const aiResponse: HistoryItem = { role: 'model', parts: [{ text: data.aiMessage }] };
      setTextToSpeak(data.aiMessage);
      setHistory(prev => [...prev, aiResponse]);
    } catch (error: any) {
      if (error.name !== 'AbortError') console.error("[sendChatMessage] Error:", error);
    } finally {
      setIsWaitingForResponse(false);
    }
  };

  const attemptToSendFromQueue = () => {
    const queueContent = messageQueueRef.current.trim();
    if (!isWaitingRef.current && queueContent) {
      sendChatMessage({ message: queueContent });
      setMessageQueue("");
    }
  };

  const smartStitch = (baseText: string, newFragment: string) => {
    const base = baseText.trim();
    const fragment = newFragment.trim();
    if (fragment.toLowerCase().startsWith(base.toLowerCase())) return fragment;
    return `${base} ${fragment}`;
  };

  const handleTranscriptUpdate = (transcript: string, isFinal: boolean) => {
    if (isSpeakingRef.current) speakerRef.current?.stop();
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    const newUtterance = smartStitch(currentUtteranceRef.current, transcript);
    setCurrentUtterance(newUtterance);
    if (isFinal && newUtterance.trim()) {
      setMessageQueue(prev => (prev ? `${prev}\n\n${newUtterance}` : newUtterance));
      setCurrentUtterance("");
      activityTimerRef.current = setTimeout(() => attemptToSendFromQueue(), 1200);
    } else if (!isFinal) {
      activityTimerRef.current = setTimeout(() => attemptToSendFromQueue(), 1500);
    }
  };

  const handleMicToggle = () => {
    const newMicState = !isMicOn;
    setIsMicOn(newMicState);
    streamerRef.current?.setMuted(!newMicState);
  };

  const handleStart = () => {
    if (streamerRef.current) streamerRef.current.stopStreaming();
    setConnectionStatus('connecting');
    setIsMicOn(true);
    const sessionId = crypto.randomUUID();
    const config = { sample_rate: 16000 };
    streamerRef.current = new LiveAudioStreamer(
      sessionId, config, handleTranscriptUpdate,
      (metrics) => setAudioLevel(metrics.speechThreshold > 0 ? Math.min(metrics.currentRms / (metrics.speechThreshold * 1.5), 1) : 0),
      () => setConnectionStatus('connected'),
      () => setConnectionStatus('error'),
      WEBSOCKET_URL,
      selectedAudioDevice
    );
    streamerRef.current.startStreaming();
  };

  useEffect(() => {
    handleStart();
    return () => {
      streamerRef.current?.stopStreaming();
      if (abortControllerRef.current) abortControllerRef.current.abort();
    };
  }, [selectedAudioDevice]);

  const handleNextClick = () => {
    setIsInteractiveQuestion(true);
    console.log('Interactive question mode activated.');
  };

  const handlePreviousClick = () => {
    setIsInteractiveQuestion(false);
    console.log('Returning to conversation mode.');
  };

  // --- Main Interview UI ---
  return (
    <div className="flex flex-col h-screen bg-slate-100 dark:bg-slate-900">
      <header className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-sm shrink-0">
        <h1 className="text-xl font-bold text-gray-800 dark:text-gray-100">Accounting Assessment</h1>
        <div className="text-sm text-muted-foreground">
          Powered by <strong>Aestim AI</strong>
        </div>
      </header>
      
      <div className="flex-1 min-h-0 p-8 flex flex-col">
        {/* The AiInterviewer is now outside of the conditional rendering, so it always exists for GSAP to target. */}
        <div className="relative h-36 mb-4">
          <div ref={avatarRef} className="absolute top-0 left-1/2">
            <AiInterviewer isListening={isListening} isSpeaking={isSpeaking} />
          </div>
        </div>

        {/* This block now only switches between the two content panels. */}
        <AnimatePresence mode="wait">
          {isInteractiveQuestion ? (
            <motion.div
              key="interactive"
              className="flex-1 flex items-start justify-center"
              initial={{ opacity: 0, x: -150 }}
              animate={{ opacity: 1, x: -160, transition: { duration: 0.9, ease: 'easeInOut', delay: 1.1 } }}
              exit={{ opacity: 0, x: 50, transition: { duration: 0.4, ease: 'easeInOut' } }}
            >
              <div className="w-2/3 max-w-3xl relative left-20 bottom-8">
                <InteractiveQuestionPanel onPreviousClick={handlePreviousClick} />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="conversation"
              className="h-full"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeInOut', delay: 0.8 } }}
              exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.4, ease: 'easeInOut' } }}
            >
              <ConversationPanel
                history={history}
                isWaitingForResponse={isWaitingForResponse}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AudioControls
        isMicOn={isMicOn}
        onMicToggle={handleMicToggle}
        audioDevices={audioDevices}
        selectedAudioDevice={selectedAudioDevice}
        onAudioChange={setSelectedAudioDevice}
        audioLevel={audioLevel}
        connectionStatus={connectionStatus}
        isInteractive={isInteractiveQuestion}
        onNextClick={handleNextClick}
        onPreviousClick={handlePreviousClick}
      />
      <CartesiaSpeaker
        ref={speakerRef}
        text={textToSpeak}
        onSpeakingStateChange={setIsSpeaking}
      />
    </div>
  );
};

export default Interview;
